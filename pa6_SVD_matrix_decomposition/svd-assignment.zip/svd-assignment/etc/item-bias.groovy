import org.lenskit.bias.BiasModel
import org.lenskit.bias.ItemBiasModel

bind BiasModel to ItemBiasModel